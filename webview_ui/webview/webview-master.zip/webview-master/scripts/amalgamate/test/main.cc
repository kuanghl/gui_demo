#include "webview_amalgamation.h"

int main() {
  webview::webview w(false, nullptr);
  return 0;
}
